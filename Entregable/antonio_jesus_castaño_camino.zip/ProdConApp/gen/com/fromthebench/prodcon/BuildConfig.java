/** Automatically generated file. DO NOT MODIFY */
package com.fromthebench.prodcon;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}